Eight Queens Problem:

	This problem is a question that asks a way to place eight queens on a 8 by 8 chessboard so that no queens attack other queens. To do so, we need to place all 8 queens so that none of them are on the same row, same column, or on diagonals of each other. 
	
How to Run the Code:

	We can run this code by making a function called int main() inside the file 8queens-all-solns.c and call putall(0). By doing so, the main() function will automatically run and call the putall(0) that prints out the solution matrix for the 8 queens problem. We can run it by going in to terminal and at the right directory, we need to write $gcc -m32 -o 8queens-all-solns 8queens-all-solns.c. 
